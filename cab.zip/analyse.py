# -*- coding: utf-8 -*-
"""Lecture des .txt : `show running-config` et `show power inline`."""
import re

# Correspondance abrege <-> nom long, identique a celle codee dans les formules
# J et N du classeur (XLOOKUP). Toute divergence casse la resolution des blocs.
ABREGES = [
    ("Twe", "TwentyFiveGigE"),   # avant "Tw", sinon "Twe1/0/1" matche "Tw"
    ("Tw", "TwoGigabitEthernet"),
    ("Te", "TenGigabitEthernet"),
    ("Gi", "GigabitEthernet"),
    ("Fa", "FastEthernet"),
    ("Po", "Port-channel"),
    ("Ap", "AppGigabitEthernet"),
    ("Hu", "HundredGigE"),
    ("Fo", "FortyGigE"),
]
LONG2ABR = {long: abr for abr, long in ABREGES}

# Interfaces physiques de brassage : celles qui aboutissent a une prise murale.
# Volontairement sans Port-channel / Vlan / Loopback / Tunnel / AppGigabitEthernet
# (interface interne du conteneur applicatif des Catalyst 9000).
PHYSIQUES = ("GigabitEthernet", "TenGigabitEthernet", "TwoGigabitEthernet",
             "TwentyFiveGigE", "FastEthernet", "HundredGigE", "FortyGigE")

RE_INTERFACE = re.compile(r"^interface\s+(\S+)\s*$")
RE_HOSTNAME = re.compile(r"^hostname\s+(\S.*?)\s*$")
RE_DESCRIPTION = re.compile(r"^\s+description\s+(.*?)\s*$")
RE_TAG_AP = re.compile(r"\(\s*AP\s*\)", re.I)


def est_ap(description):
    """Vrai si la description contient le marqueur metier (AP)."""
    return bool(RE_TAG_AP.search(description or ""))

# Le numero de prise dans la description. Notations relevees sur le parc :
#   Z7-2001_P1234        Z7-2001 P1234        Z7-2001-P1234
#   Z7-2001(P1234)       Z7-2001 (P1234)      _P0089  (local vide)
# et toutes suivies, ou non, d'un commentaire libre :
#   z1-2116-03_P0123 (xxxx)      C1-5015-00_P0197 (max 4)
#   C2-2065-00_P0338 trap enable C1-1101-00_P0411  2ieme
# Les zeros de tete tombent : la colonne « Anc. Prise » est numerique et les
# VLOOKUP en dependent.
#
# On CHERCHE le motif au lieu de l'ancrer en fin de chaine : ancre, tout ce qui
# suivait le numero (un commentaire du technicien) faisait rater la prise et
# expediait le port en « hors gabarit ».
#
# Deux garde-fous, tous deux necessaires :
#
# 1. Le separateur -- espace, souligne, tiret -- ou la parenthese ouvrante
#    avant le P est OBLIGATOIRE. Sans lui, « AIR-AP2802I-A-K9 » donnerait
#    local « AIR-A » + prise 2802, un nom d'equipement pris pour une prise.
#
# 2. Le caractere qui SUIT le P doit etre un chiffre. Toute lettre entre le P
#    et le numero exclut : « PDU20A », « PA20 », « PoE12 », « Panneau3 »...
#    En revanche des lettres APRES le numero sont acceptees et ignorees, car
#    les techniciens y annotent le port (« _P0197 (max 4) », « _P0338 trap
#    enable », « _P0411  2ieme »). C'est `0*(\d+)` qui porte cette regle :
#    apres le P viennent des zeros de tete puis des chiffres, rien d'autre.
RE_PRISE = re.compile(r"(?:[\s_\-]|\()\s*\(?\s*P0*(\d+)", re.I)


def extraire_local_prise(description):
    """« C1-5015-00_P0197 (max 4) » -> ("C1-5015-00", 197).

    (None, None) si la description ne porte aucun numero de prise.
    """
    m = RE_PRISE.search(description)
    if not m:
        return None, None
    return description[:m.start()].strip(" _-("), int(m.group(1))


def abreger(nom):
    """GigabitEthernet1/0/1 -> Gi1/0/1 (format attendu par la formule J)."""
    for long_, abr in sorted(LONG2ABR.items(), key=lambda kv: -len(kv[0])):
        if nom.startswith(long_):
            return abr + nom[len(long_):]
    return nom


class Interface:
    __slots__ = ("nom", "abrege", "lignes", "description", "local", "prise")

    def __init__(self, nom, lignes):
        self.nom = nom
        self.abrege = abreger(nom)
        self.lignes = lignes          # bloc complet, « interface X » inclus
        self.description = None
        self.local = None
        self.prise = None
        for l in lignes:
            m = RE_DESCRIPTION.match(l)
            if m:
                self.description = m.group(1)
                self.local, self.prise = extraire_local_prise(self.description)
                break

    @property
    def physique(self):
        return self.nom.startswith(PHYSIQUES)


class Switch:
    def __init__(self, nom, lignes_config):
        self.nom = nom
        self.lignes = lignes_config       # config brute, telle qu'ecrite en col. A
        self.interfaces = []              # [Interface] dans l'ordre du fichier
        self.poe = {}                     # abrege -> dict(admin, power, ...)
        self.sans_poe = False             # tableau POE present mais vide
        self.avertissements = []
        self.hostname = next((m.group(1) for m in
                              (RE_HOSTNAME.match(l) for l in lignes_config) if m),
                             None)
        self._decouper()

    def _decouper(self):
        """Decoupe la config en blocs « interface X ... ! »."""
        courant, nom = None, None
        for l in self.lignes:
            m = RE_INTERFACE.match(l)
            if m:
                if courant is not None:
                    self.interfaces.append(Interface(nom, courant))
                nom, courant = m.group(1), [l]
            elif courant is not None:
                if l.strip() == "!":
                    self.interfaces.append(Interface(nom, courant))
                    courant, nom = None, None
                else:
                    courant.append(l)
        if courant is not None:
            self.interfaces.append(Interface(nom, courant))


def lire_config(chemin):
    """Lit un .txt de config. Ne normalise que les fins de ligne.

    Le reste est laisse strictement intact : la formule J fait un
    MATCH("interface " & ..., plage, 0) exact et cherche le « ! » de fin de
    bloc, donc toucher a l'indentation ou supprimer les « ! » casserait tout.
    """
    with open(chemin, "r", encoding="utf-8", errors="replace") as f:
        brut = f.read()
    if brut.startswith("﻿"):
        brut = brut[1:]
    return [l.rstrip("\r\n") for l in brut.split("\n")]


# --- show power inline -------------------------------------------------------
# Interface Admin  Oper       Power   Device              Class Max
#                             (Watts)
# --------- ------ ---------- ------- ------------------- ----- ----
# Gi1/0/1   auto   off        0.0     n/a                 n/a   30.0
RE_POE = re.compile(
    r"^\s*([A-Za-z]{2,3}\d+(?:/\d+)*)"      # Interface
    r"\s+(auto|off|static|on|never)"        # Admin
    r"\s+(\S+)"                             # Oper
    r"\s+([\d.]+)"                          # Power (Watts)
    r"\s+(.+?)"                             # Device (peut contenir des espaces)
    r"\s+(n/a|\d+(?:\.\d+)?)"               # Class
    r"\s+([\d.]+)\s*$"                      # Max
)


RE_ENTETE_POE = re.compile(r"^\s*Interface\s+Admin\s+Oper\s+Power", re.I)


def lire_poe(chemin):
    """-> ({abrege: {admin, oper, power, device, classe, max}}, entete_vue).

    `entete_vue` distingue les deux facons d'obtenir zero ligne :
      - entete presente, tableau vide  -> le switch n'a tout simplement pas de
        PoE (les 2960/2961/2962 du parc sortent « Module 1 : n/a n/a n/a »),
        c'est normal et il ne faut pas crier au fichier illisible ;
      - pas d'entete du tout           -> le fichier n'est pas un « show power
        inline », la, il y a un vrai probleme.
    """
    res, entete = {}, False
    with open(chemin, "r", encoding="utf-8", errors="replace") as f:
        for ligne in f:
            if RE_ENTETE_POE.match(ligne):
                entete = True
                continue
            m = RE_POE.match(ligne.rstrip())
            if not m:
                continue
            iface, admin, oper, power, device, classe, maxi = m.groups()
            res[iface] = {"admin": admin, "oper": oper, "power": float(power),
                          "device": device.strip(), "classe": classe.strip(),
                          "max": float(maxi)}
    return res, entete


def etat_poe(info, description=None):
    """Colonne POE du classeur : POE si le port debite du courant, sinon NON-POE.

    C'est une CONSIGNE DE BRASSAGE, pas une propriete de la prise. Elle dit au
    technicien sur quel type de port rebrancher : pas de jus sur l'ancien port
    -> pas besoin de PoE sur le nouveau. C'est pour ca que « Power = 0 » donne
    NON-POE meme quand le port est capable de PoE (Max = 30 W) : la question
    n'est pas « ce port supporte-t-il le PoE », mais « faut-il du PoE ici ».

    Ne pas la transformer en trois etats sous pretexte que « Power = 0 » ne
    distingue pas « rien de branche » de « equipement non-PoE » : cette
    distinction n'interesse pas le technicien qui brasse.

    Verification sur le classeur d'origine : « Changements Z7-0002 » suit cette
    regle sur ses 384 lignes sans une exception (260 NON-POE a 0 W, 124 POE au-
    dessus). « Changements Z7-1920 » ne la suit pas du tout -- 98 ports y tirent
    du courant en etant marques NON-POE et 89 ports a 0 W sont marques POE --
    parce que sa colonne a ete remplie a la main avec un autre sens (le besoin
    futur). Elle ne fait donc pas foi ici.
    """
    if not info or info["power"] <= 0:
        return "NON-POE"
    return "POE (AP)" if est_ap(description) else "POE"
